"use strict";



const salesData = {

  "Region1": [1540, 1130, 1580, 1105],

  "Region2": [2010, 1168, 2305, 4102],

  "Region3": [2450, 1847, 2710, 2391],

  "Region4": [1845, 1491, 1284, 1575],

  "Region5": [2120, 1767, 1599, 3888]

};



// Calculate total sales

function calculateTotalSales(regionSales) {

  return regionSales.reduce((total, quarterSales) => total + quarterSales, 0);

}



// Calculate quarterly sales for a specific quarter (e.g., Q1)

function calculateQuarterlySales(quarterIndex) {

  const quarterlySales = [];

  for (const region in salesData) {

    quarterlySales.push(salesData[region][quarterIndex]);

  }

  return quarterlySales;

}



// Display Quarterly Sales

document.write("<h2>Quarterly Sales</h2>");

for (let quarterIndex = 0; quarterIndex < 4; quarterIndex++) {

  const quarterlySales = calculateQuarterlySales(quarterIndex);

  document.write(`Q${quarterIndex + 1}: $${quarterlySales.reduce((total, sales) => total + sales, 0)}<br>`);

}



// Display Sales by Region

document.write("<h2>Sales by Region</h2>");

for (const region in salesData) {

  const regionSales = calculateTotalSales(salesData[region]);

  document.write(`${region}: $${regionSales}<br>`);

}



// Calculate and Display Total Sales

let totalAllRegions = 0;

for (const region in salesData) {

  totalAllRegions += calculateTotalSales(salesData[region]);

}

document.write("<h2>Total Sales</h2>");

document.write(`Total Sales: $${totalAllRegions}`);
  
