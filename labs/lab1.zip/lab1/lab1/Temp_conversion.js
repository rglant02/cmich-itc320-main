"use strict";

// Function to validate the input temperature is within the specified range
function validateInput(temperature) {
    return temperature >= -100 && temperature <= 212;
}

// Function to convert Celsius to Fahrenheit
for (let i = 0; i < 3; i++){
function convertToFahrenheit(celsius) {
    return (celsius * 9/5) + 32;
}

// Prompt the user to enter a Fahrenheit temperature
const fahrenheit = parseFloat(prompt("Enter Fahrenheit temperature:"));

// Check if the input is not a number or not within the valid range

if (isNaN(fahrenheit) || !validateInput(fahrenheit)) {
    // Display an alert for invalid input
    alert("Please enter a valid Fahrenheit temperature between -100 and 212.");
} else {
    // Calculate the equivalent Celsius temperature
    const celsius = (fahrenheit - 32) * 5/9;

    // Generate HTML to display both Fahrenheit and Celsius temperatures
    const html = `
        <p>${fahrenheit}F = ${celsius.toFixed(2)}C</p>
        
    `;

    
    document.write(html);
}
  }

