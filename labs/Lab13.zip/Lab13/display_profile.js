"use strict";

$(document).ready( () => {
	// display data from session storage
	
	$("back").click( () => {
		
	}); // end of click()
	
}); // end of ready()