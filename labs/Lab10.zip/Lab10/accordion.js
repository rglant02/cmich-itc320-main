$(document).ready(function() {
    $("#accordion").accordion({
      collapsible: true, // Allow closing panels
      active: false // Start with all panels closed
    });
  });