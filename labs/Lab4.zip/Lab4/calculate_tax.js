"use strict";
        const $ = selector => document.querySelector(selector);
        document.addEventListener("DOMContentLoaded", () => {
            // add event handlers
            $("#clear").addEventListener("click", clear_click);
            $("#calculate").addEventListener("click", calculate_click);
        });


        //var $ = function(id) {

        //return document.getElementById(id);

        //};
        var calculate_click = function () {

            var subtotal = parseFloat($("#subtotal").value);
            var taxRate = parseFloat($("#taxrate").value); // Updated to use correct ID
            var haveError = false;
            if (subtotal <= 0 || subtotal > 10000) {
                $("#subtotal_message").innerHTML = "Must be a positive number less than $10,000";
                haveError = true;
            } else {
                $("#subtotal_message").innerHTML = "";
            }
            if (taxRate <= 0 || taxRate >= 12) {
                $("#tax_rate_message").innerHTML = "Must be a positive number less than 12";
                haveError = true;
            } else {
                $("#tax_rate_message").innerHTML = "";
            }
            if (!haveError) {
                var tax_value = subtotal * (taxRate / 100.0);
                $("#salestax").value = tax_value.toFixed(2); // Update ID to use correct ID
                $("#total").value = (subtotal + tax_value).toFixed(2);
            }

        };


        var clear_click = function () {
            $("#subtotal").value = "";
            $("#taxrate").value = ""; // Update to use correct ID
            $("#subtotal_message").innerHTML = "Enter order subtotal";
            $("#tax_rate_message").innerHTML = "Enter sales tax rate (0-12)"; // Update message
            $("#salestax").value = ""; // Update ID to use correct ID
            $("#total").value = "";
        };
        window.onload = function () {
            $("#subtotal").focus();
        };