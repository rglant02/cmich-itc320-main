'use strict';

for (let i = 0; i < 3; i++) {
  // Ask for the value
  let num = parseInt(prompt('Enter number grade from 0 through 100\nOr enter 999 to end entries'));

  // If the user entered 999, exit the loop
  if (num === 999) {
    break;
  }

  // Validate the input
  if (num < 0 || num > 100 || isNaN(num)) {
    alert('Invalid input. Please enter a valid number between 0 and 100.');
    i--; // Decrement i to allow the user to enter a valid input for this iteration
    continue;
  }

  // Determine the grade based on the input
  let grade;
  if (num < 60) {
    grade = 'F';
  } else if (num < 68) {
    grade = 'D';
  } else if (num < 80) {
    grade = 'C';
  } else if (num < 88) {
    grade = 'B';
  } else {
    grade = 'A';
  }

  // Display the grade and its associated letter
  const html = `<p>Grade   ${num}, = ${grade}</p>`;
  document.write(html);
}